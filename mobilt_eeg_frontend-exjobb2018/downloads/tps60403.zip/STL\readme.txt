 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: D:\Export_Storage\ExportBase\0\252961\Output\STL\STL
 
 
To import your new 3D models follow these steps:

Select your view and open it.
File load the STL file located at the address above.

We use and recommend using the free reader from http://www.stpviewer.com/

Or for color renderings use http://www.freecad.com/


**************************************************************
**    !!!!!!!!!!!!!        WARNING        !!!!!!!!!!!!!     **
**************************************************************

Besure to check the documentation layer for important information that may seem to be missing or have not translated properly!



For additional information, please visit this site:
http://www.accelerated-designs.com/help/STL.html

To see a video tutorial of this process, please visit:
http://youtu.be/eTT0_6xa0so
 
 
Symbol "TPS60403-Q1_DBV_5" renamed to "TPS60403-Q1_DBV_"
Component "TPS60403-Q1_DBV_5" renamed to "TPS60403-Q1_DBV_"
3 ASCII STL files exported.
